/*!
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
export default function safeAccessPath(obj: any, ...path: any[]): any;
//# sourceMappingURL=safeAccessPath.d.ts.map