/*!
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
export {};
//# sourceMappingURL=parseNetworkLogs.d.ts.map