/*!
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
export * from './setSoundStateOptions';
export * from './soundCommand';
//# sourceMappingURL=index.d.ts.map