"use strict";
/*!
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * The layer that the collider should be assigned to.
 */
// export enum CollisionLayer {
//     Object = 'object',
//     Environment = 'environment',
//     Hologram = 'hologram'
// }
//# sourceMappingURL=collision.js.map